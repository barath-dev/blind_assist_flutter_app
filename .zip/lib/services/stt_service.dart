
class STT {
  static final STT _instance = STT._internal();
  factory STT() => _instance;
  STT._internal();

    void _initSpeech()async{
      
    }

}
