
const OPENAI_API_KEY = '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';
